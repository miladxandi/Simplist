<?php
define('PATH',__DIR__.DIRECTORY_SEPARATOR.'..');
define('VIEW',PATH.DIRECTORY_SEPARATOR.'../View/View/');