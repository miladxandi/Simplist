<?php
if($_REQUEST['username']=="Admin" && $_REQUEST['password']=="123456")
{
    var_dump($_REQUEST);
    $_SESSION['username']=$_REQUEST['username'];
    $_SESSION['password']=$_REQUEST['password'];
    var_dump($_SESSION);

}
else
{
    header("Location: /Login");
}
?>
<div>
    <div><a href="/Panel/Maps">Maps</a></div>
</div>