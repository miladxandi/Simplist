<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" type="image/x-icon" href="../../../../Content/Shared/Logo.png" id="favicon">
    <link rel="apple-touch-icon" type="image/x-icon" href="../../../../Content/Shared/Logo.png">
    <link rel="apple-touch-icon" type="image/x-icon" href="../../../../Content/Shared/Logo.png">
    <!-- Twitter -->
    <meta name="twitter:site" content="@themepixels">
    <meta name="twitter:creator" content="@themepixels">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Starlight">
    <meta name="twitter:description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="twitter:image" content="http://themepixels.me/starlight/img/starlight-social.png">

    <!-- Facebook -->
    <meta property="og:url" content="http://themepixels.me/starlight">
    <meta property="og:title" content="Starlight">
    <meta property="og:description" content="Premium Quality and Responsive UI for Dashboard.">

    <meta property="og:image" content="http://themepixels.me/starlight/img/starlight-social.png">
    <meta property="og:image:secure_url" content="http://themepixels.me/starlight/img/starlight-social.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="600">

    <!-- Meta -->
    <meta name="description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="author" content="ThemePixels">

    <title>SIMPLIST - LOGIN</title>

    <!-- vendor css -->
    <?php
    $Adder = new \Model\Repository\MainFunction\AssetsLoader();
    $Adder->Loader("css","Panel/font-awesome");
    $Adder->Loader("css","Panel/ionicons");
    $Adder->Loader("css","Panel/starlight");
    $Adder->Loader("css","Panel/mytest");
    $Adder->Loader("js","Panel/jquery");
    $Adder->Loader("js","Panel/popper");
    $Adder->Loader("js","Panel/bootstrap");

    /*$Adder->Loader("css","Panel/all");
    $Adder->Loader("css","Panel/all");
    $Adder->Loader("css","Panel/all");
    $Adder->Loader("css","Panel/all");*/
    ?>
</head>

<body style="background-color:#154360;">
<form accept-charset="UTF-8" action="/Login" method="POST" id="loginform" >
    <div class="d-flex align-items-center justify-content-center bg-sl-primary ht-md-100v">

        <div class="login-wrapper wd-300 wd-xs-400 pd-25 pd-xs-40 bg-white">
            <div class="signin-logo tx-center tx-24 tx-bold tx-inverse DefinedFonts">صفحه <span class="tx-info DefinedFonts"  tx-bold>ثبت نام</span></div>
            <br>


            <div class="Simplistlogo" >Simplist</div>
            <!--    <div class="tx-center mg-b-60">طراحی قالب حرفه ای</div>-->

            <div class="form-group">
                <div class="form-group col-sm-6 mg-t-20 mg-sm-t-0 " tabindex="1" style="float: left">
                    <input type="text" class="form-control DefinedFonts" name="lname" placeholder="نام خوانوادگی">
                </div><!-- form-group -->

                <div class="form-group col-sm-6 mg-t-20 mg-sm-t-0 "  style="float: left">
                    <input type="text" class="form-control DefinedFonts" name="fname" placeholder="نام">
                </div><!-- form-group -->

                <div class="form-group col-sm-6 mg-t-20 mg-sm-t-0 " tabindex="2" style="float: left">
                    <input type="password" class="form-control DefinedFonts" name="password" placeholder="کلمه عبور">
                </div><!-- form-group -->

                <div class="form-group col-sm-6 mg-t-20 mg-sm-t-0 " tabindex="3" style="float: left">
                    <input type="text" class="form-control DefinedFonts" name="username" placeholder="نام کاربری">
                </div><!-- form-group -->


                <div class="form-group col-sm-6 mg-t-20 mg-sm-t-0 " tabindex="5" style="float: left">
                    <input type="email" class="form-control DefinedFonts" name="email" placeholder="پست الکترونیک">
                </div><!-- form-group -->

                <div class="form-group col-sm-6 mg-t-20 mg-sm-t-0 " tabindex="6" style="float: left">
                    <input type="tel" class="form-control DefinedFonts" name="telphone" placeholder="تلفن">
                </div><!-- form-group -->


                <div class="form-group" style="float: right; clear: both; direction: rtl; margin-right: 15px">
                    <label class="d-block tx-11 tx-uppercase tx-medium tx-spacing-1"></label>
                    <div class="row row-xs DefinedFonts" style="margin-left: -9%">
                        <div class="col-sm-4 mg-t-20 mg-sm-t-0 DefinedFonts">
                            <select class="form-control select2 DefinedFonts" tabindex="7" data-placeholder="روز">
                                <option label="روز"></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                                <option value="13">13</option>
                                <option value="14">14</option>
                                <option value="15">15</option>
                                <option value="16">16</option>
                                <option value="17">17</option>
                                <option value="18">18</option>
                                <option value="19">19</option>
                                <option value="20">20</option>
                                <option value="21">21</option>
                                <option value="22">22</option>
                                <option value="23">23</option>
                                <option value="24">24</option>
                                <option value="25">25</option>
                                <option value="26">26</option>
                                <option value="27">27</option>
                                <option value="28">28</option>
                                <option value="29">29</option>
                                <option value="30">30</option>
                                <option value="31">31</option>
                            </select>
                        </div><!-- col-4 -->
                        <div class="col-sm-4 mg-t-20 mg-sm-t-0 DefinedFonts">
                            <select class="form-control select2 DefinedFonts" tabindex="8" data-placeholder=" ماه">
                                <option label="ماه"></option>
                                <option value="1">فروردین</option>
                                <option value="2">اردیبهشت</option>
                                <option value="3">خرداد</option>
                                <option value="4">تیر</option>
                                <option value="5">مرداد</option>
                                <option value="6">شهریور</option>
                                <option value="7">مهر</option>
                                <option value="8">آبان</option>
                                <option value="9">آذر</option>
                                <option value="10">دی</option>
                                <option value="11">بهمن</option>
                                <option value="12">اسفند</option>
                            </select>
                        </div><!-- col-4 -->

                        <div class="col-sm-4 mg-t-20 mg-sm-t-0 DefinedFonts" style="margin-left: -10px">
                            <select class="form-control select2 DefinedFonts" tabindex="9" data-placeholder="سال">
                                <option label="سال"></option>
                                <option value="20">1320</option>
                                <option value="21">1321</option>
                                <option value="22">1322</option>
                                <option value="23">1323</option>
                                <option value="24">1324</option>
                                <option value="25">1325</option>
                                <option value="26">1326</option>
                                <option value="27">1327</option>
                                <option value="28">1328</option>
                                <option value="29">1329</option>
                                <option value="30">1330</option>
                                <option value="31">1331</option>
                                <option value="32">1332</option>
                                <option value="33">1333</option>
                                <option value="34">1334</option>
                                <option value="35">1335</option>
                                <option value="36">1336</option>
                                <option value="37">1337</option>
                                <option value="38">1338</option>
                                <option value="39">1339</option>
                                <option value="40">1340</option>
                                <option value="41">1341</option>
                                <option value="42">1342</option>
                                <option value="43">1343</option>
                                <option value="44">1344</option>
                                <option value="45">1345</option>
                                <option value="46">1346</option>
                                <option value="47">1347</option>
                                <option value="48">1348</option>
                                <option value="49">1349</option>
                                <option value="50">1350</option>
                                <option value="51">1351</option>
                                <option value="52">1352</option>
                                <option value="53">1353</option>
                                <option value="54">1354</option>
                                <option value="55">1355</option>
                                <option value="56">1356</option>
                                <option value="57">1357</option>
                                <option value="58">1358</option>
                                <option value="59">1359</option>
                                <option value="60">1360</option>
                                <option value="61">1361</option>
                                <option value="62">1362</option>
                                <option value="63">1363</option>
                                <option value="64">1364</option>
                                <option value="65">1365</option>
                                <option value="66">1366</option>
                                <option value="67">1367</option>
                                <option value="68">1368</option>
                                <option value="694">1369</option>

                                <option value="70">1370</option>
                                <option value="71">1371</option>
                                <option value="72">1372</option>
                                <option value="73">1373</option>
                                <option value="74">1374</option>
                                <option value="75">1375</option>
                                <option value="76">1376</option>
                                <option value="77">1377</option>
                                <option value="78">1378</option>
                                <option value="79">1379</option>
                                <option value="80">1380</option>
                                <option value="81">1381</option>
                                <option value="82">1382</option>
                                <option value="83">1383</option>
                                <option value="84">1384</option>
                                <option value="85">1385</option>
                            </select>
                        </div><!-- col-4 -->
                    </div><!-- row -->
                </div><!-- form-group -->
                <!--   <div class="form-group tx-12">By clicking the Sign Up button below, you agreed to our privacy policy and terms of use of our website.</div>-->
                <button type="submit" tabindex="10" class="btn btn-info btn-block DefinedFonts">ثبت نام</button>
                <div class="mg-t-40 tx-center DefinedFonts">در حال حاضر یک حساب کاربری دارید؟<a href="/Login" class="tx-info DefinedFonts"><br>ورود </a></div>
            </div><!-- login-wrapper -->
        </div><!-- d-flex -->
    </div>
</form>
<script src="../lib/jquery/jquery.js"></script>
<script src="../lib/popper.js/popper.js"></script>
<script src="../lib/bootstrap/bootstrap.js"></script>
<script src="../lib/select2/js/select2.min.js"></script>
<script>
    $(function(){
        'use strict';

        $('.select2').select2({
            minimumResultsForSearch: Infinity
        });
    });
</script>
</body>
</html>
