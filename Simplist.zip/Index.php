<?php

require "Core\Requirement\Autoloader.php";
require "Route\Core\Router.php";
require "Route\Constant\Main.php";
\Route\Core\Router::Register();
