<?php

//Do not remove these classes.

namespace Core\Watcher;

abstract class Core
{
    public $Main_Folders;
    public $Sub_Folders;
    public $Version;
    public $OS;
}
