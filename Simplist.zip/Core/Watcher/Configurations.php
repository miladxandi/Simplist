<?php

namespace Core\Watcher;


final class Configurations extends Core
{
    public $Version = PHP_VERSION;
    public $OS = PHP_OS;
}