function alert() {
    alert('Hey');
}