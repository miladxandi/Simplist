<?php
/**
 * Created by PhpStorm.
 * User: farva
 * Date: 31/01/2018
 * Time: 04:38 AM
 */

namespace Controller\Helper;


use Route\Show\View;

class ErrorController
{

    public function NotFound()
    {
        View::Process("Helper.Home.NotFound");
    }

}